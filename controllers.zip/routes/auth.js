//auth routing
const { Router } = require("express");
const router = Router();

const{
	login,
	register,
	logout,
}	= require('../controllers/auth.js');

router.route('/login').post(login);
router.route('/register').post(register);
router.route('/logout').post(logout)

module.exports = router; 